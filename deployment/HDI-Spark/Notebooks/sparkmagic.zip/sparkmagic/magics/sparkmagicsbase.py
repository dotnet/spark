# -*- coding: UTF-8 -*-

"""Runs Scala, PySpark and SQL statement through Spark using a REST endpoint in remote cluster.
Provides the %spark magic."""

# Copyright (c) 2015  aggftw@gmail.com
# Distributed under the terms of the Modified BSD License.

from __future__ import print_function
from IPython.core.magic import Magics, magics_class
from hdijupyterutils.ipythondisplay import IpythonDisplay

import re

import sparkmagic.utils.configuration as conf
from sparkmagic.utils.sparklogger import SparkLog
from sparkmagic.utils.sparkevents import SparkEvents
from sparkmagic.utils.sparkmatplot import PowerMatlib
from sparkmagic.utils.utils import get_sessions_info_html
from sparkmagic.utils.constants import MAGICS_LOGGER_NAME, REPLACE_SYMBOLS_FOR_BASE64IMAGE, MIMETYPE_TEXT_HTML, MIMETYPE_TEXT_PLAIN
from sparkmagic.livyclientlib.sparkcontroller import SparkController
from sparkmagic.livyclientlib.sqlquery import SQLQuery
from sparkmagic.livyclientlib.command import Command
from sparkmagic.livyclientlib.sparkstorecommand import SparkStoreCommand


@magics_class
class SparkMagicBase(Magics):
    def __init__(self, shell, data=None, spark_events=None):
        # You must call the parent constructor
        super(SparkMagicBase, self).__init__(shell)

        self.logger = SparkLog(u"SparkMagics")
        self.ipython_display = IpythonDisplay()
        self.spark_controller = SparkController(self.ipython_display)

        self.logger.debug("Initialized spark magics.")

        if spark_events is None:
            spark_events = SparkEvents()
        spark_events.emit_library_loaded_event()

    def execute_spark(self, cell, output_var, samplemethod, maxrows, samplefraction, session_name, coerce):
        (success, out, mimetype) = self.spark_controller.run_command(
            Command(cell), session_name)
        if not success:
            self.ipython_display.send_error(out)
        else:
            self._print_out_to_front(out, mimetype)
            if output_var is not None:
                spark_store_command = self._spark_store_command(
                    output_var, samplemethod, maxrows, samplefraction, coerce)
                df = self.spark_controller.run_command(
                    spark_store_command, session_name)
                self.shell.user_ns[output_var] = df

    @staticmethod
    def _spark_store_command(output_var, samplemethod, maxrows, samplefraction, coerce):
        return SparkStoreCommand(output_var, samplemethod, maxrows, samplefraction, coerce=coerce)

    def execute_sqlquery(self, cell, samplemethod, maxrows, samplefraction,
                         session, output_var, quiet, coerce):
        sqlquery = self._sqlquery(
            cell, samplemethod, maxrows, samplefraction, coerce)
        df = self.spark_controller.run_sqlquery(sqlquery, session)
        if output_var is not None:
            self.shell.user_ns[output_var] = df
        if quiet:
            return None
        else:
            return df

    @staticmethod
    def _sqlquery(cell, samplemethod, maxrows, samplefraction, coerce):
        return SQLQuery(cell, samplemethod, maxrows, samplefraction, coerce=coerce)

    def _print_endpoint_info(self, info_sessions, current_session_id):
        if info_sessions:
            info_sessions = sorted(info_sessions, key=lambda s: s.id)
            html = get_sessions_info_html(info_sessions, current_session_id)
            self.ipython_display.html(html)
        else:
            self.ipython_display.html(u'No active sessions.')

    def _print_out_to_front(self, out, mimetype):
        _reg_for_extract_base64img = re.compile(
            r"\{'image/png':\s*u?'(.*?)'\}", re.DOTALL)
        data_need_to_convert_to_img = _reg_for_extract_base64img.findall(out)

        generator_for_img_data = (data for data in data_need_to_convert_to_img)
        out_without_base64img = _reg_for_extract_base64img.sub(
            REPLACE_SYMBOLS_FOR_BASE64IMAGE, out)

        # if not contain the data that neeed to render to img, just print user results
        # it also means that user not call matlib plot in their code
        if not data_need_to_convert_to_img:
	    if mimetype == MIMETYPE_TEXT_HTML:
                self.ipython_display.html(out)
            else:
                self.ipython_display.write(out)
            return

        strings = out_without_base64img.split('\n')
        for string in strings:
            if string.strip() == REPLACE_SYMBOLS_FOR_BASE64IMAGE:
                figure = PowerMatlib.generate_img_from_base64(
                    next(generator_for_img_data))
                self.ipython_display.display(figure)
            else:
                self.ipython_display.write(string + "\n")
